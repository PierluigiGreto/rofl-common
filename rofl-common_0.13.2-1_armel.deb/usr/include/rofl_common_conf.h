/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
 
#ifndef __ROFL_COMMON_CONF_H__
#define __ROFL_COMMON_CONF_H__

/* Name of package */
#define ROFL_COMMON_PACKAGE "rofl-common"

/* Define to the address where bug reports for this package should be sent. */
#define ROFL_COMMON_PACKAGE_BUGREPORT "rofl-devel@roflibs.org"

/* Define to the full name of this package. */
#define ROFL_COMMON_PACKAGE_NAME "ROFL-COMMON"

/* Define to the full name and version of this package. */
#define ROFL_COMMON_PACKAGE_STRING "ROFL-COMMON 0.13.2"

/* Define to the one symbol short name of this package. */
#define ROFL_COMMON_PACKAGE_TARNAME "rofl-common"

/* Define to the home page for this package. */
#define ROFL_COMMON_PACKAGE_URL "http://www.roflibs.org"

/* Define to the version of this package. */
#define ROFL_COMMON_PACKAGE_VERSION "0.13.2"

/* Compiled in branch(local) */
#define ROFL_COMMON_BRANCH "master"

/* Build (git hash) */
#define ROFL_COMMON_BUILD "f1abe0a59b653ac06c33767b7aea15fc67639ee9"

/* Git describe */
#define ROFL_COMMON_DESCRIBE "v0.13.2"

/* ROFL version */
#define ROFL_COMMON_VERSION_ "0.13.2"

/* Experimental */
//Compiled without experimental support

#endif //__ROFL_COMMON_CONFIG_H__
